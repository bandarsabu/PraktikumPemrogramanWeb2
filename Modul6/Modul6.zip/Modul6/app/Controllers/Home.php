<?php

namespace App\Controllers;

use App\Models\profilmodel;

class Home extends BaseController
{
    public function index()
    {
        $mahasiswa = new profilmodel();
        return view('index', [
            "nama" => $mahasiswa->getNama(),
            "nim" => $mahasiswa->getNim(),
        ]);
    }

        public function biodata(){
        $mahasiswa = new profilmodel();
        return view('biodata', [
            "nama" => $mahasiswa->getNama(),
            "nim" => $mahasiswa->getNim(),
            "citacita" => $mahasiswa->getcita_cita(),
            "skill" => $mahasiswa->getSkill(),
            "prodi" => $mahasiswa->getProdi(),
            "motivasi" => $mahasiswa->getMotivasi(),
            "hobi" => $mahasiswa->gethobi(),
            "foto1" => $mahasiswa->getFoto1()
        ]);
    }
}