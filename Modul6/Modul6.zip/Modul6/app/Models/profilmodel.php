<?php

namespace App\Models;

use CodeIgniter\Model;

class profilmodel extends Model
{
    protected $nama = "Akhiratul Akmal Agustiannoor";
    protected $nim = "2110817110012";
    protected $prodi = "Teknologi Informasi";
    protected $cita_cita = "Pengusaha";
    protected $hobi = "Nonton film";
    protected $skill = "Front End & Desain Grafis";
    protected $motivasi = "Gak kerja Gak Makan";
    protected $foto1 = "foto1.jpg";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getcita_cita()
    {
        return $this->cita_cita;
    }
    public function gethobi()
    {
        return $this->hobi;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getMotivasi()
    {
        return $this->motivasi;
    }

    public function getFoto1()
    {
        return $this->foto1;
    }
}